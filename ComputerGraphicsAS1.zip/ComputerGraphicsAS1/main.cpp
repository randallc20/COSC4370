/*
The assignment requires the rasterization of the arcs of two circles. 
The first circle is defined as x2 +y2 = R2 where x 􏰁 0 and R = 100. 
The second circle is defined as x2 + y2 = R2 where y 􏰁 0 and R = 150. 
The radius is 200, and the dimension of the image will be radius × radius (200 × 200).

*/


#include <iostream>
#include "BMP.h"
#include <cmath>

int main() {
    //creates the width and height
    BMP bmpNew(2000,800,false);
    bmpNew.fill_region(0, 0, 2000, 800, 0, 0, 0, 0);//makes this region all black

    //draw white line along the x axis or more specifically where y = 0 because the second place is 0
    for(int i=0;i<bmpNew.bmp_info_header.width;i++){

        bmpNew.set_pixel(i, 0, 255, 255, 255, 0);
    }

    //goes through all the x pixels and prints out the y 
    for(int x=0;x<bmpNew.bmp_info_header.width;x++)
    {
      if((x >= 232) && (x <= 1768)){//size of the ellipse each way
        int x2 = x - 1000;
        int y = (int) (sqrt(589824 - (x2 * x2))/2);
        bmpNew.set_pixel(x, y, 255, 255, 255, 0);
      }

    }
    bmpNew.write("output.bmp");


}